"""Sheratan Version Reconciler - Merge and reconcile multiple Sheratan installations."""

__version__ = "1.0.0"
__author__ = "Sheratan Team"
