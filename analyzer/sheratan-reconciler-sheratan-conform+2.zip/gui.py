"""GUI interface for Sheratan Version Reconciler using tkinter."""

import tkinter as tk
from tkinter import ttk, filedialog, scrolledtext, messagebox
from pathlib import Path
import threading
from src.app import SheratanReconciler


class SheratanReconcilerGUI:
    """GUI application for Sheratan Version Reconciler."""
    
    def __init__(self, root):
        """Initialize GUI.
        
        Args:
            root: Tkinter root window
        """
        self.root = root
        self.root.title("Sheratan Version Reconciler")
        self.root.geometry("900x700")
        
        # Initialize reconciler
        self.reconciler = None
        self.directories = {}
        
        # Create GUI elements
        self.create_widgets()
    
    def create_widgets(self):
        """Create all GUI widgets."""
        # Title
        title_frame = ttk.Frame(self.root, padding="10")
        title_frame.pack(fill=tk.X)
        
        title_label = ttk.Label(
            title_frame,
            text="Sheratan Version Reconciler",
            font=("Arial", 16, "bold")
        )
        title_label.pack()
        
        subtitle_label = ttk.Label(
            title_frame,
            text="Compare and merge multiple Sheratan installations",
            font=("Arial", 10)
        )
        subtitle_label.pack()
        
        # Directory selection
        dir_frame = ttk.LabelFrame(self.root, text="Sheratan Directories", padding="10")
        dir_frame.pack(fill=tk.X, padx=10, pady=5)
        
        # Directory list
        self.dir_listbox = tk.Listbox(dir_frame, height=4)
        self.dir_listbox.pack(fill=tk.X, pady=5)
        
        # Directory buttons
        btn_frame = ttk.Frame(dir_frame)
        btn_frame.pack(fill=tk.X)
        
        ttk.Button(btn_frame, text="Add Directory", command=self.add_directory).pack(side=tk.LEFT, padx=2)
        ttk.Button(btn_frame, text="Remove Selected", command=self.remove_directory).pack(side=tk.LEFT, padx=2)
        ttk.Button(btn_frame, text="Clear All", command=self.clear_directories).pack(side=tk.LEFT, padx=2)
        
        # Operations
        ops_frame = ttk.LabelFrame(self.root, text="Operations", padding="10")
        ops_frame.pack(fill=tk.X, padx=10, pady=5)
        
        ttk.Button(ops_frame, text="Scan & Analyze", command=self.scan_directories, width=20).pack(side=tk.LEFT, padx=5)
        ttk.Button(ops_frame, text="Generate Report", command=self.generate_report, width=20).pack(side=tk.LEFT, padx=5)
        ttk.Button(ops_frame, text="Merge Versions", command=self.merge_versions, width=20).pack(side=tk.LEFT, padx=5)
        
        # Options
        options_frame = ttk.LabelFrame(self.root, text="Options", padding="10")
        options_frame.pack(fill=tk.X, padx=10, pady=5)
        
        self.backup_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(options_frame, text="Create backups before merge", variable=self.backup_var).pack(anchor=tk.W)
        
        self.dry_run_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(options_frame, text="Dry run (preview only)", variable=self.dry_run_var).pack(anchor=tk.W)
        
        # Output
        output_frame = ttk.LabelFrame(self.root, text="Output", padding="10")
        output_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        self.output_text = scrolledtext.ScrolledText(output_frame, height=20, wrap=tk.WORD)
        self.output_text.pack(fill=tk.BOTH, expand=True)
        
        # Status bar
        self.status_var = tk.StringVar(value="Ready")
        status_bar = ttk.Label(self.root, textvariable=self.status_var, relief=tk.SUNKEN, anchor=tk.W)
        status_bar.pack(fill=tk.X, side=tk.BOTTOM)
    
    def add_directory(self):
        """Add a directory to the list."""
        directory = filedialog.askdirectory(title="Select Sheratan Directory")
        if directory:
            path = Path(directory)
            version_name = path.name
            self.directories[version_name] = path
            self.dir_listbox.insert(tk.END, f"{version_name}: {directory}")
            self.log(f"Added directory: {directory}")
    
    def remove_directory(self):
        """Remove selected directory from list."""
        selection = self.dir_listbox.curselection()
        if selection:
            index = selection[0]
            item = self.dir_listbox.get(index)
            version_name = item.split(":")[0]
            
            self.dir_listbox.delete(index)
            if version_name in self.directories:
                del self.directories[version_name]
            
            self.log(f"Removed directory: {version_name}")
    
    def clear_directories(self):
        """Clear all directories."""
        self.dir_listbox.delete(0, tk.END)
        self.directories.clear()
        self.log("Cleared all directories")
    
    def scan_directories(self):
        """Scan and analyze directories."""
        if not self.directories:
            messagebox.showwarning("No Directories", "Please add at least one directory to scan.")
            return
        
        self.log("\n" + "="*60)
        self.log("SCANNING DIRECTORIES")
        self.log("="*60)
        
        def scan_thread():
            try:
                self.status_var.set("Scanning...")
                self.reconciler = SheratanReconciler()
                results = self.reconciler.scan(self.directories)
                
                if 'error' in results:
                    self.log(f"ERROR: {results['error']}")
                else:
                    summary = results.get('summary', {})
                    self.log(f"\nScan Results:")
                    self.log(f"  Versions: {summary.get('version_count', 0)}")
                    self.log(f"  Total Files: {summary.get('total_files', 0)}")
                    self.log(f"  Common Files: {summary.get('common_files', 0)}")
                    self.log(f"  Different Files: {summary.get('different_files', 0)}")
                    self.log(f"  Unique Files: {summary.get('unique_files', 0)}")
                    self.log(f"  Config Conflicts: {summary.get('conflicts', 0)}")
                    self.log("\n✓ Scan complete!")
                
                self.status_var.set("Scan complete")
            except Exception as e:
                self.log(f"ERROR: {str(e)}")
                self.status_var.set("Error during scan")
        
        thread = threading.Thread(target=scan_thread, daemon=True)
        thread.start()
    
    def generate_report(self):
        """Generate comparison report."""
        if not self.directories:
            messagebox.showwarning("No Directories", "Please add at least one directory.")
            return
        
        # Ask for save location
        filename = filedialog.asksaveasfilename(
            defaultextension=".md",
            filetypes=[("Markdown", "*.md"), ("JSON", "*.json"), ("HTML", "*.html"), ("All Files", "*.*")]
        )
        
        if not filename:
            return
        
        self.log("\n" + "="*60)
        self.log("GENERATING REPORT")
        self.log("="*60)
        
        def report_thread():
            try:
                self.status_var.set("Generating report...")
                
                if not self.reconciler:
                    self.reconciler = SheratanReconciler()
                
                output_path = Path(filename)
                self.reconciler.compare(self.directories, output_path)
                
                self.log(f"\n✓ Report saved to: {filename}")
                self.status_var.set("Report generated")
                
                messagebox.showinfo("Success", f"Report saved to:\n{filename}")
            except Exception as e:
                self.log(f"ERROR: {str(e)}")
                self.status_var.set("Error generating report")
        
        thread = threading.Thread(target=report_thread, daemon=True)
        thread.start()
    
    def merge_versions(self):
        """Merge versions into unified installation."""
        if not self.directories:
            messagebox.showwarning("No Directories", "Please add at least one directory to merge.")
            return
        
        if len(self.directories) < 2:
            messagebox.showwarning("Insufficient Directories", "Please add at least 2 directories to merge.")
            return
        
        # Ask for output directory
        output_dir = filedialog.askdirectory(title="Select Output Directory for Merged Version")
        if not output_dir:
            return
        
        # Confirm merge
        if not self.dry_run_var.get():
            response = messagebox.askyesno(
                "Confirm Merge",
                f"Merge {len(self.directories)} versions into:\n{output_dir}\n\nBackups: {'Yes' if self.backup_var.get() else 'No'}\n\nContinue?"
            )
            if not response:
                self.log("Merge cancelled by user")
                return
        
        self.log("\n" + "="*60)
        self.log("MERGING VERSIONS")
        self.log("="*60)
        
        def merge_thread():
            try:
                self.status_var.set("Merging...")
                
                if not self.reconciler:
                    self.reconciler = SheratanReconciler()
                
                # Update config
                self.reconciler.config['backup_originals'] = self.backup_var.get()
                
                results = self.reconciler.merge(
                    self.directories,
                    Path(output_dir),
                    dry_run=self.dry_run_var.get()
                )
                
                if results.get('cancelled'):
                    self.log("Merge cancelled")
                    self.status_var.set("Cancelled")
                elif results.get('dry_run'):
                    self.log("\n✓ Dry run complete - no files modified")
                    self.status_var.set("Dry run complete")
                elif results.get('success'):
                    self.log(f"\n✓ Merge complete!")
                    self.log(f"  Output: {output_dir}")
                    self.log(f"  Files merged: {results.get('merged_file_count', 0)}")
                    self.log(f"  Conflicts resolved: {results.get('conflict_count', 0)}")
                    self.status_var.set("Merge complete")
                    
                    messagebox.showinfo("Success", f"Merge complete!\n\nOutput: {output_dir}")
                else:
                    self.log("ERROR: Merge failed")
                    self.status_var.set("Merge failed")
            except Exception as e:
                self.log(f"ERROR: {str(e)}")
                self.status_var.set("Error during merge")
                messagebox.showerror("Error", f"Merge failed:\n{str(e)}")
        
        thread = threading.Thread(target=merge_thread, daemon=True)
        thread.start()
    
    def log(self, message):
        """Log message to output text area.
        
        Args:
            message: Message to log
        """
        self.output_text.insert(tk.END, message + "\n")
        self.output_text.see(tk.END)
        self.root.update_idletasks()


def main():
    """Main entry point for GUI application."""
    root = tk.Tk()
    app = SheratanReconcilerGUI(root)
    root.mainloop()


if __name__ == '__main__':
    main()
