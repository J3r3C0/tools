# Sheratan Version Reconciler - Sheratan-Conform+2

Ein spezialisiertes Tool zum Vergleichen und Zusammenführen mehrerer Sheratan-Installationen.

## 🎯 Was ist das?

Der **Sheratan Version Reconciler** hilft dir dabei, mehrere Sheratan-Installationen zu vergleichen, Unterschiede zu analysieren und sie intelligent zu einer einheitlichen Version zusammenzuführen.

### Perfekt für:
- ✅ Zusammenführen von Entwicklungs- und Produktionsversionen
- ✅ Synchronisieren mehrerer Sheratan-Knoten
- ✅ Migrieren von Änderungen zwischen Installationen
- ✅ Identifizieren von Konfigurationsdrift
- ✅ Erstellen einer einheitlichen Master-Version

## 🚀 Schnellstart

### Installation

```bash
# ZIP entpacken
# In das Verzeichnis wechseln
cd sheratan-reconciler

# Abhängigkeiten installieren
pip install -r requirements.txt
```

### Grundlegende Verwendung

#### 1. Versionen scannen
```bash
python -m src.main scan C:\sauber_main C:\sheratan_backup
```

#### 2. Vergleichsbericht erstellen
```bash
python -m src.main compare C:\sauber_main C:\sheratan_backup -o bericht.md
```

#### 3. Versionen zusammenführen
```bash
python -m src.main merge C:\sauber_main C:\sheratan_backup -o C:\sheratan_unified
```

## 📋 Hauptfunktionen

### 🔍 Intelligente Analyse
- **Dateistruktur-Vergleich**: Findet fehlende, zusätzliche und geänderte Dateien
- **Code-Analyse**: AST-basierter Vergleich von Python-Code
- **Konfigurations-Drift**: Erkennt Unterschiede in YAML, JSON, .env Dateien
- **Schweregrad-Bewertung**: Klassifiziert Änderungen nach Wichtigkeit

### 🔀 Intelligentes Merging
- **Mehrere Strategien**: Neueste, Manuell, Regelbasiert
- **Automatische Konfliktlösung**: Für einfache Fälle
- **Backup-Erstellung**: Sichert Originale vor dem Merge
- **Union-Merge**: Für requirements.txt und Dependencies

### 📊 Umfassende Berichte
- **Markdown-Format**: Für Menschen lesbar
- **JSON-Format**: Für maschinelle Verarbeitung
- **HTML-Format**: Für Web-Ansicht
- **Detaillierte Diffs**: Mit Zeilennummern und Kontext

## 🎮 Befehle

### `scan` - Versionen analysieren
```bash
python -m src.main scan [VERZEICHNISSE...] [OPTIONEN]

Optionen:
  -c, --config PFAD  Pfad zur Konfigurationsdatei
```

**Beispiel:**
```bash
python -m src.main scan C:\sheratan_v1 C:\sheratan_v2 C:\sheratan_v3
```

### `compare` - Vergleichsbericht erstellen
```bash
python -m src.main compare [VERZEICHNISSE...] [OPTIONEN]

Optionen:
  -o, --output PFAD   Ausgabedatei (Standard: sheratan_comparison_report.md)
  -f, --format TEXT   Format: markdown, json, html (Standard: markdown)
  -c, --config PFAD   Pfad zur Konfigurationsdatei
```

**Beispiel:**
```bash
python -m src.main compare C:\sauber_main C:\sheratan_backup -o vergleich.md
```

### `merge` - Versionen zusammenführen
```bash
python -m src.main merge [VERZEICHNISSE...] [OPTIONEN]

Optionen:
  -o, --output PFAD   Ausgabeverzeichnis für zusammengeführte Version
  --dry-run           Testlauf ohne Änderungen
  -c, --config PFAD   Pfad zur Konfigurationsdatei
```

**Beispiel:**
```bash
python -m src.main merge C:\sheratan_v1 C:\sheratan_v2 -o C:\sheratan_final
```

### `report` - Berichte exportieren
```bash
python -m src.main report [VERZEICHNISSE...] [OPTIONEN]

Optionen:
  -c, --config PFAD   Pfad zur Konfigurationsdatei
```

## ⚙️ Sheratan-Spezifische Konfiguration

Diese Version enthält **vorkonfigurierte Einstellungen** für Sheratan-Installationen:

### Vorkonfigurierte Pfade
Die Konfiguration kennt typische Sheratan-Strukturen:
- `mesh/offgrid/`
- `core/`
- `workers/`
- `config/`

### Sheratan-spezifische Ignore-Patterns
Automatisch ignoriert werden:
- Job-Dateien (`job_*.json`, `result_*.json`)
- Worker-Verzeichnisse (`input/`, `output/`, `queue/`)
- Logs und temporäre Dateien
- Cache-Verzeichnisse

### Spezielle Merge-Regeln
Für kritische Sheratan-Dateien:
- **Core-Komponenten** (`core.py`, `orchestrator.py`): Manuelle Überprüfung
- **Worker-Dateien** (`worker.py`, `api_real.py`): Neueste mit meisten Funktionen
- **Konfiguration** (`.env`, `config.yaml`): Keys zusammenführen
- **Dependencies** (`requirements.txt`): Union aller Versionen

## 🛠️ Konfiguration

### Sheratan-Konfiguration verwenden
```bash
python -m src.main merge [DIRS...] -c config/sheratan-config.yaml
```

### Eigene Konfiguration erstellen
Kopiere `config/sheratan-config.yaml` und passe sie an:

```yaml
merge_strategy: newest
backup_originals: true
output_directory: ./sheratan-unified

ignore_patterns:
  - "*.log"
  - "job_*.json"
  - "input/"
  - "output/"
```

## 📖 Batch-Skripte

Für häufige Operationen sind Batch-Skripte enthalten:

### `sheratan-scan.bat`
Schnelles Scannen zweier Versionen:
```batch
sheratan-scan.bat C:\sheratan_v1 C:\sheratan_v2
```

### `sheratan-compare.bat`
Vergleichsbericht erstellen:
```batch
sheratan-compare.bat C:\sheratan_v1 C:\sheratan_v2
```

### `sheratan-merge.bat`
Versionen zusammenführen:
```batch
sheratan-merge.bat C:\sheratan_v1 C:\sheratan_v2 C:\sheratan_unified
```

## 💡 Workflow-Empfehlung

### Vor dem Merge:

1. **Scannen** der Versionen
   ```bash
   python -m src.main scan C:\sheratan_v1 C:\sheratan_v2
   ```

2. **Bericht erstellen** und überprüfen
   ```bash
   python -m src.main compare C:\sheratan_v1 C:\sheratan_v2 -o bericht.md
   ```

3. **Testlauf** durchführen
   ```bash
   python -m src.main merge C:\sheratan_v1 C:\sheratan_v2 --dry-run
   ```

4. **Bericht überprüfen** - Besonders achten auf:
   - Änderungen in `core.py`, `orchestrator.py`, `worker.py`
   - Konfigurationskonflikte in `.env` und `config.yaml`
   - Fehlende kritische Dateien

### Während des Merge:

1. **Backups aktiviert lassen** (Standard)
2. **Kritische Dateien** manuell überprüfen
3. **Ausgabe beobachten** für Fehler oder Warnungen

### Nach dem Merge:

1. **Vereinheitlichte Version testen**
2. **Sheratan starten** und Funktionalität prüfen
3. **Backups behalten** bis alles verifiziert ist
4. **Änderungen dokumentieren**

## 🔒 Sicherheit

### Automatische Backups
Vor jedem Merge werden automatisch Backups erstellt:
```
sheratan_v1_backup_20260121_120000/
sheratan_v2_backup_20260121_120000/
```

### Manuelle Überprüfung
Sicherheitskritische Dateien erfordern immer manuelle Überprüfung:
- `.env` Dateien
- `secrets.yaml`
- API-Keys und Credentials

### Dry-Run Modus
Teste Änderungen ohne Dateien zu modifizieren:
```bash
python -m src.main merge [DIRS...] --dry-run
```

## 🐛 Fehlerbehebung

### "Keine gültigen Verzeichnisse gefunden"
- Überprüfe, ob die Pfade existieren
- Stelle sicher, dass du Leserechte hast

### Merge-Konflikte
- Verwende zuerst `--dry-run`
- Überprüfe den Vergleichsbericht
- Nutze manuelle Auflösung für kritische Dateien

### Fehlende Abhängigkeiten
```bash
pip install -r requirements.txt
```

## 📊 Beispiel-Ausgabe

### Scan-Ergebnis:
```
Scanning 2 Sheratan versions...
  ✓ sauber_main: C:\sauber_main
  ✓ sheratan_v2: C:\sheratan_backup

Analyzing file structures...
Analyzing code differences...
Analyzing configuration drift...

Scan Results:
  Versions: 2
  Total Files: 245
  Different Files: 12
  Conflicts: 3

✓ Scan complete!
```

### Merge-Ergebnis:
```
Merging 2 Sheratan versions...
Output directory: C:\sheratan_unified

Creating backups...
  ✓ Backup: C:\sauber_main_backup_20260121_120000
  ✓ Backup: C:\sheratan_backup_backup_20260121_120000

Merging files...
  Files merged: 245
  Conflicts resolved: 12
  Unique files copied: 8

✓ Merge complete!
```

## 📚 Weitere Dokumentation

- `docs/architecture.md` - Technische Architektur
- `docs/usage_examples.md` - Praktische Beispiele
- `config/sheratan-config.yaml` - Konfigurationsoptionen
- `config/sheratan-rules.yaml` - Merge-Regeln

## 🆘 Support

Bei Fragen oder Problemen:
1. Überprüfe die Dokumentation in `docs/`
2. Schaue dir `docs/usage_examples.md` für häufige Szenarien an
3. Teste mit `--dry-run` vor echten Änderungen

## 📄 Lizenz

MIT License - Frei verwendbar und anpassbar

## 🎉 Version

**Sheratan-Conform+2**  
**Version**: 2.0  
**Build**: Januar 2026  
**Python**: 3.11+

---

**Bereit für die Sheratan-Reconciliation!** 🚀
