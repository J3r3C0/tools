# Sheratan Version Reconciler - Schnellstart-Anleitung

## 🚀 Sofort loslegen

### 1. Zwei Sheratan-Versionen vergleichen

**Doppelklick auf:** `sheratan-compare.bat`

Oder im Terminal:
```batch
sheratan-compare.bat C:\sauber_main C:\sheratan_backup
```

**Ergebnis:** Erstellt einen Vergleichsbericht `sheratan_vergleich_YYYYMMDD_HHMMSS.md`

---

### 2. Versionen scannen

**Doppelklick auf:** `sheratan-scan.bat`

Oder im Terminal:
```batch
sheratan-scan.bat C:\sheratan_v1 C:\sheratan_v2
```

**Ergebnis:** Zeigt Zusammenfassung der Unterschiede

---

### 3. Testlauf (Dry Run)

**Doppelklick auf:** `sheratan-dryrun.bat`

Oder im Terminal:
```batch
sheratan-dryrun.bat C:\sheratan_v1 C:\sheratan_v2 C:\ausgabe
```

**Ergebnis:** Zeigt was passieren würde, OHNE Dateien zu ändern

---

### 4. Versionen zusammenführen

**Doppelklick auf:** `sheratan-merge.bat`

Oder im Terminal:
```batch
sheratan-merge.bat C:\sheratan_v1 C:\sheratan_v2 C:\sheratan_unified
```

**Ergebnis:** Erstellt vereinheitlichte Version in `C:\sheratan_unified`

---

## 💡 Empfohlener Workflow

```
1. SCANNEN
   └─> sheratan-scan.bat [Verzeichnisse...]
   
2. VERGLEICHEN
   └─> sheratan-compare.bat [Verzeichnisse...]
   └─> Bericht überprüfen!
   
3. TESTLAUF
   └─> sheratan-dryrun.bat [Verzeichnisse...] [Ausgabe]
   └─> Ausgabe überprüfen!
   
4. ZUSAMMENFÜHREN
   └─> sheratan-merge.bat [Verzeichnisse...] [Ausgabe]
   └─> Ergebnis testen!
```

---

## ⚙️ Sheratan-Spezifische Features

### Automatisch ignoriert:
- ✅ Job-Dateien (`job_*.json`, `result_*.json`)
- ✅ Worker-Verzeichnisse (`input/`, `output/`, `queue/`)
- ✅ Logs und Cache
- ✅ Temporäre Dateien

### Intelligentes Merging:
- ✅ **Core-Dateien** (core.py, orchestrator.py): Manuelle Überprüfung
- ✅ **Worker-Dateien**: Neueste mit meisten Funktionen
- ✅ **Konfiguration**: Keys zusammenführen
- ✅ **Dependencies**: Union aller Versionen

### Automatische Backups:
- ✅ Vor jedem Merge werden Backups erstellt
- ✅ Format: `verzeichnis_backup_YYYYMMDD_HHMMSS/`

---

## 🎯 Häufige Szenarien

### Szenario 1: Entwicklung → Produktion
```batch
REM 1. Vergleichen
sheratan-compare.bat C:\dev\sheratan C:\prod\sheratan

REM 2. Testlauf
sheratan-dryrun.bat C:\dev\sheratan C:\prod\sheratan C:\merged

REM 3. Zusammenführen
sheratan-merge.bat C:\dev\sheratan C:\prod\sheratan C:\merged
```

### Szenario 2: Mehrere Versionen vereinen
```batch
REM Alle drei Versionen zusammenführen
sheratan-merge.bat C:\sheratan_v1 C:\sheratan_v2 C:\sheratan_v3 C:\final
```

### Szenario 3: Nur scannen
```batch
REM Schneller Überblick über Unterschiede
sheratan-scan.bat C:\sheratan_old C:\sheratan_new
```

---

## 🔧 Erweiterte Nutzung

### Eigene Konfiguration verwenden
```batch
python -m src.main merge [DIRS...] -c meine-config.yaml
```

### Nur bestimmte Dateitypen analysieren
Bearbeite `config\sheratan-config.yaml`:
```yaml
analyze_extensions:
  - ".py"
  - ".yaml"
```

### Andere Merge-Strategie
Bearbeite `config\sheratan-config.yaml`:
```yaml
merge_strategy: manual  # oder: newest, rules
```

---

## 🐛 Probleme?

### Batch-Skript funktioniert nicht
- Stelle sicher, dass du im Projektverzeichnis bist
- Überprüfe, ob Python installiert ist: `python --version`
- Installiere Dependencies: `pip install -r requirements.txt`

### "Keine gültigen Verzeichnisse"
- Überprüfe die Pfade
- Verwende absolute Pfade (z.B. `C:\...`)
- Stelle sicher, dass die Verzeichnisse existieren

### Merge-Fehler
- Führe zuerst einen Dry Run durch
- Überprüfe den Vergleichsbericht
- Stelle sicher, dass du Schreibrechte hast

---

## 📚 Weitere Hilfe

- **Vollständige Dokumentation**: `README_DE.md`
- **Technische Details**: `docs/architecture.md`
- **Beispiele**: `docs/usage_examples.md`
- **Konfiguration**: `config/sheratan-config.yaml`

---

**Viel Erfolg beim Reconciling!** 🚀
